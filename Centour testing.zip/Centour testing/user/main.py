

if __name__ == "__main__":
    print('Test Case Execution Start')
    try:
        import loginCentor
    except Exception as e :
        print(e)
    try:
        import checkIN
    except Exception as e :
        print(e)
    print('Test Case Execution End')

    try:
        import checkOut
    except Exception as e :
        print(e)
    print("Test Case Execution  check out ")

    try:
        import Orders
    except Exception as e :
        print(e)
    print("Test case Exection Order ")
    try:
        import orderREports
    except Exception as e :
        print(e)
    print("click button not working ")
    try :
        import Documentvault
    except Exception as e :
        print(e)
    print("Click button not working "'')
    try:
        import AddException
    except Exception as e :
        print(e)
    print("Running Add Expence /t")
    try :
        import ReportChk
    except Exception as e :
        print(e)
    print("test cases in check in report /t")
    try:
        import ReportExpense
    except Exception as e :
        print(e)
    print("Test cases download  /t")
    try:
        import contact
    except  Exception as e :
        print(e)
    print("Test cases of contact number ")
    try:
        import logout
    except Exception as e :
        print(e)
    print("Test cases logout ")